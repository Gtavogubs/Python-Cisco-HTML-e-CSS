soma = 0 # Inicializa a variável soma
for i in range(5):
    numero = float(input(f"Digite o {i + 1}º número: "))
    soma += numero # Adiciona o número à variável soma

print(f"A Soma dos números é: {soma}")
