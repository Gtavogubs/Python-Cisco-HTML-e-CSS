print("Vamos adicionar 5 nomes numa lista.")
n = []
n.append(str(input("Qual é o primeiro nome? \n")))
n.append(str(input("Qual é o segundo nome? \n")))
n.append(str(input("Qual é o terceiro nome? \n")))
n.append(str(input("Qual é o quarto nome? \n")))
n.append(str(input("Qual é o quinto nome? \n")))

print(n)