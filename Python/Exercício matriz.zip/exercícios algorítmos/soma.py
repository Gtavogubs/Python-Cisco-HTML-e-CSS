print("Vamos somar números.")
a = int(input("Qual é o primeiro número? \n"))
b = int(input("Qual é o segundo número? \n"))
c = a + b 
print(f"O total da sua soma é {c}.")