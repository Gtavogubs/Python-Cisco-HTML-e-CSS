print("Vamos transformar sua idade em dias.")
idade = int(input("Quantos anos você tem?\n"))
dias = idade * 365
horas = idade * 8760
print(f"Sua idade em dias: {dias} dias \n")
print(f"E em horas sua idade fica como: {horas} horas \n")