print("Vamos ver se você está elegível à aposentadoria.")
idade = int(input("Qual é a sua idade? \n"))
if idade > 62:
    print("Você pode se aposentar, desfaz o L")
else:
    print("Vai trabalhar vagabundo")