print("Hora de checar as letrinhas.")
resposta = str(input("Qual letra você deseja checar hoje? \n"))
if resposta in ('a', 'e' , 'i' , 'o' , 'u'):
    print("Sua letra é uma vogal.")
else:
    print("Sua letra é uma consoante.")