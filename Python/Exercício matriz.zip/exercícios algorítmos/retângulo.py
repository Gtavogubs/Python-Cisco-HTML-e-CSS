print("Vamos calcular a área do retângulo.")
base = int(input("Sabemos que área de retângulo se dá por base * altura. Qual é a base do retângulo?\n"))
altura = int(input("Qual é a altura do retângulo?\n"))
area = base * altura 
print(f"A área do retângulo são {area} cm.\n")
