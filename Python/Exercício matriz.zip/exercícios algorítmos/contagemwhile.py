n = 1
while n < 10:
   n += 1
   print(f"bora fi {n}")
   