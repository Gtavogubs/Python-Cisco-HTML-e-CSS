print("Vamos somar 5 números.")
a = int(input("Primeiro númmero: \n"))
b = int(input("Segundo númmero: \n"))
c = int(input("Terceiro númmero: \n"))
d = int(input("Quarto númmero: \n"))
e = int(input("Quinto númmero: \n"))
soma = a + b + c + d + e 
print(f"O resultado dessa soma é {soma}")
