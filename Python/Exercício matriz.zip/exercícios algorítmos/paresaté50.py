for i in range(2, 51, 2):
    print(f"Números pares até 50: {i}")