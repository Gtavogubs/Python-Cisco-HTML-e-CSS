print("Bem vindo ao conversor de Celsius para Fahrenheit.")
C = int(input("Qual é o clima em Justinópolis hoje?\n"))
F = (C * 9/5) + 32 
print(f" {C} graus Celsius em Fahrenheit são {F}F°. \n")
