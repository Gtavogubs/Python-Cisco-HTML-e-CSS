print("Essa é a lista completa dos múltiplos de 3:")
for i in range(3, 100, 3):
    print(f"números: ", i)

print("Deu Brasil.")
