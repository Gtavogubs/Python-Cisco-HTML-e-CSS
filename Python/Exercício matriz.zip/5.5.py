goiaba = []
goiaba.append(str(input("Qual tipo de goiaba você quer adicionar? \n")))
goiaba.append(str(input("Teria outra? \n")))
goiaba.append(str(input("Mais alguma? \n")))
goiaba.append(str(input("Mais uma, pra rir. \n")))
print(goiaba , "Só tem goiaba ruim velho!")
print("A terceira goiaba é: \n", goiaba[2] )
print("A primeira goiaba é: \n", goiaba[-1])