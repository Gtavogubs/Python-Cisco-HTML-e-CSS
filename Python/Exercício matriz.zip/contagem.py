import time
print("Vamos contar de 1 até 10")
for i in range(1,11):
    print(i)
    print(f"Contagem regressiva: {i}")
    time.sleep(1)