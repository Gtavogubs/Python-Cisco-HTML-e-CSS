# Define uma função chamada 'inicio'
def inicio():
    # Declaração e atribuição de valores para duas variáveis
    num1 = 7
    num2 = 10

    # Realiza a soma duas variáveis e armazena o resultado na variável 'soma'
    soma = num1 + num2

    # Exibe o resultado da soma no controle
    print(soma)

# Chama a função 'inicio' para executar o código
inicio()