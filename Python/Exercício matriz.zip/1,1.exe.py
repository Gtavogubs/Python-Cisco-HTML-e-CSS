# Criando exercício de operações matemáticas.
print("Vamos praticar exercícios.")
num1 = 1
num2 = 2
num3 = 3
num4 = 4
soma = num2 + num4
print("A Soma é representada pelo + sendo: 2 + 4 = \n" , soma)
subtracao = num1 - num3
print("A Subtração é representada pelo - sendo: 1 - 3 = \n" , subtracao)
multiplicacao = num4 * num4
print("A multiplicação é representada pelo * sendo: 4 * 4 = \n" , multiplicacao)
divisao = num4 / num2
print("A divisão é representada pelo / sendo: 4 / 2 = \n" , divisao)



