import time
for a in range(20,0,-1):
    print(f"Contagem regressiva para o lançamento dos mísseis:", a)
    time.sleep(0.50)
print("Boom! O CT do Atlético foi destruído!")        

