print("Bom dia, vamos converter Celsius (C°) para Fahrenheit (F°)")
print("É comumente conhecido que para se converter Celsius para Fahrenheit é necessário multiplicar a temperatura em Celsius por 1,8. \n")
celsius = float(input("Quantos graus Celsius está fazendo em Justinópolis, agora? "))
fahrenheit = celsius * 1.8 + 32
print(f"A Conversão de Celsius para Fahrenheit em Justinópolis é: {fahrenheit}F°")