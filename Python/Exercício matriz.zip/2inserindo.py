
num1 = 11 # Define um número fixo para a multiplicação

num2 = float(input("Digite o segundo número:")) # Solicita ao usuário um número e converte para float

multiplicacao = num1 * num2 # Multiplica os dois valores

print(f"\n A multiplicação dos número é igual a: {multiplicacao}") # Exibe o resultado da multiplicação.

