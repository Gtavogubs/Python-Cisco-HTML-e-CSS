print("Vamos começar as operações aritméticas.")
print("\n Digite o primeiro número, começaremos com a múltiplicação.")

num1 = float(input("Digite o primeiro número: "))
num2 = float(input("Digite o segundo número: "))
mult = num1 * num2
print(f"O Resultado é: {mult}. ")
print("Agora partindo para divisão. \n")
num3 = float(input("Escolha o primeiro número: "))
num4 = float(input("Escolha o segundo número: "))
divi = num3 / num4
print(f"O resultado é: {divi}")
