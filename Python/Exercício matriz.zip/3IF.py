def saberseonumero():
    a = 1
    b = 4
    c = a + b
    print(c, "\n")

    if c < 6:
        print("É um número pequeno\n")
    elif c < 15:
        print("É um número grande\n")
    else:
        print("É um número grandão\n")

# Chamando a função para executar programa

saberseonumero()