pares = []
for i in range(7, 50, 7):
    pares.append(i)

print("Números: " , pares)