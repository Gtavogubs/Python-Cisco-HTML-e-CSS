print("Você está dirigindo em direção ao shopping Justinópolis, mas você está se aproximando de um sinal.")
print("São três opções de sinal, sendo Vermelho = 1, Amarelo = 2 e Verde = 3.\n")
cordofarol = input(print("Qual é a cor que você está vendo?"))
if cordofarol == 'vermelho':
    print("Pare, não siga adiante.")
elif cordofarol == 'amarelo':
    print("Diminua ou siga adiante, a vida é sua mesmo.")
elif cordofarol == 'verde':
    print("ACELERAAA") 