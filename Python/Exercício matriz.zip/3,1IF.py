print("Bem vindo ao leitor de números. Aqui você poderá ver se o seu número favorito é grande ou pequeno.")
numero = float(input("Qual é o seu número favoito?: "))

if numero < 10:
    print("Seu número é menor que o atlético mineirokkkk")
elif numero < 50:
    print("Seu número está dentro da média.")
else:
    print("Seu número parece o Cruzeiro Esporte Clube de tão grande.")
        
    